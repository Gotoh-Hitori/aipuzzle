<script setup lang="ts">
import { useRouter } from 'vue-router'

const router = useRouter()

const handleStart = () => {
  const roomId = Math.floor(100000 + Math.random() * 900000)
  router.push({ name: 'chat', query: { roomId } })
}
</script>

<template>
  <div class="landing">
    <section class="hero-card">
      <p class="eyebrow">Brain Teaser</p>
      <h1>AI 脑筋急转弯</h1>
      <p class="sub">简单的问答，逐步逼近真相。点击开始，开启一局新的海龟汤。</p>
      <a-button type="primary" size="large" @click="handleStart">开始</a-button>
    </section>
  </div>
</template>

<style scoped>
.landing {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 48px 16px;
}

.hero-card {
  background: rgba(255, 255, 255, 0.7);
  border: 1px solid rgba(255, 255, 255, 0.3);
  border-radius: 14px;
  padding: 36px 32px;
  max-width: 520px;
  width: min(94vw, 520px);
  box-shadow: 0 12px 30px rgba(0, 0, 0, 0.15);
  backdrop-filter: blur(12px) saturate(140%);
  text-align: center;
}

.eyebrow {
  letter-spacing: 4px;
  text-transform: uppercase;
  color: var(--muted);
  font-size: 12px;
  margin-bottom: 12px;
}

h1 {
  font-size: 30px;
  margin: 0;
  color: var(--text);
  letter-spacing: 1px;
}

.sub {
  margin: 16px 0 24px;
  color: var(--muted);
  line-height: 1.7;
}
</style>
