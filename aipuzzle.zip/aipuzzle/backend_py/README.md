# Python 后端（FastAPI）

用 FastAPI 重写的轻量后端，接口保持与 Vue 前端一致。

## 运行方式
```bash
cd backend_py
python -m venv .venv
.venv\Scripts\activate  # PowerShell 在 Windows 上
pip install -r requirements.txt
uvicorn backend_py.app:app --host 0.0.0.0 --port 8080 --reload
```

- 前端已将 `/api` 代理到 `http://localhost:8080`，保持默认端口即可直接联通。
- 环境变量：
  - `PORT`（默认 `8080`）
  - `SYSTEM_PROMPT` 自定义系统提示词
  - `BOT_ID` / `ARK_API_KEY` / `ARK_BASE_URL` 预留给接入真实模型（当前使用规则逻辑兜底）

## 接口
- `POST /{roomId}/chat?userPrompt=...` 返回纯文本回复
- `GET /rooms` 获取活跃房间（去掉系统提示）
- `GET /health` 健康检查
