from typing import List, Literal

from pydantic import BaseModel, ConfigDict, Field

ChatRole = Literal["SYSTEM", "USER", "ASSISTANT"]


class ChatMessage(BaseModel):
    role: ChatRole
    content: str


class ChatRoom(BaseModel):
    room_id: int = Field(..., alias="roomId")
    chat_message: List[ChatMessage] = Field(default_factory=list, alias="chatMessage")

    model_config = ConfigDict(populate_by_name=True)
