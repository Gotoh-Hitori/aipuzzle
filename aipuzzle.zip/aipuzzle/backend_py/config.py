import os

# Core game instructions for the system message. Override via SYSTEM_PROMPT env if needed.
SYSTEM_PROMPT = os.getenv(
    "SYSTEM_PROMPT",
    "你是一位脑筋急转弯“海龟汤”游戏主持人。当用户说“开始”时，先给出一道题目，并提醒只能回答“是”“否”“与此无关”。"
    "之后每次回复只给出这三类回答或简短引导，绝不要自己连续提问并回答，也不要一次把整个对话或答案全部说完。"
    "用户结束或你判断可以结束时，回复“游戏结束”并给出汤底。",
)

# Optional远程模型配置（如果需要对接火山方舟或其他模型，可通过环境变量注入）
BOT_ID = os.getenv("BOT_ID", "")
ARK_API_KEY = os.getenv("ARK_API_KEY", "dcc99de3-1d5c-44cb-a57b-257f128117d5")
ARK_BASE_URL = os.getenv("ARK_BASE_URL", "https://ark.cn-beijing.volces.com/api/v3/")

PORT = int(os.getenv("PORT", "8080"))
