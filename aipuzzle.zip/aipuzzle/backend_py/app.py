from __future__ import annotations

from fastapi import FastAPI, Query
from fastapi.responses import PlainTextResponse

from . import config
from .models import ChatRoom
from .services import ChatService

app = FastAPI(
    title="AI Chat (Python)",
    description="FastAPI rewrite of the chat backend used by the Vue frontend.",
    version="1.0.0",
)

chat_service = ChatService()


@app.get("/health")
async def health_check():
    return {"status": "ok"}


@app.get("/rooms", response_model=list[ChatRoom], response_model_by_alias=True)
async def list_rooms():
    return chat_service.get_rooms()


@app.post("/{room_id}/chat", response_class=PlainTextResponse)
async def do_chat(
    room_id: int,
    userPrompt: str = Query(..., description="用户输入的提问"),
):
    answer = await chat_service.do_chat(room_id, userPrompt)
    return answer


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("backend_py.app:app", host="0.0.0.0", port=config.PORT, reload=True)
