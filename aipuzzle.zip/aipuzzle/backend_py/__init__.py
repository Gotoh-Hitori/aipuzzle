"""Python FastAPI backend for the AI chat app."""
