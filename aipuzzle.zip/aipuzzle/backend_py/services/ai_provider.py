from __future__ import annotations

import random
from abc import ABC, abstractmethod
from typing import List, Optional

from ..models import ChatMessage


class AIProvider(ABC):
    @abstractmethod
    async def generate(self, messages: List[ChatMessage]) -> str:
        """Generate a reply given the running chat history."""
        raise NotImplementedError


class RuleBasedAIProvider(AIProvider):
    """
    A lightweight fallback that mimics yes/no guidance for the “海龟汤” game.
    This keeps the app usable without连接真实大模型。
    """

    def __init__(self) -> None:
        self.default_puzzle = (
            "一名旅客走进海边小馆点了碗海鲜汤，喝了一口后失魂落魄地走出门。"
            "请通过是/否/与此无关的提问找出真相。"
        )
        self.default_solution = "他想起了当年的海难，这碗汤让他确信当时遇难的船员真的死去。"

    async def generate(self, messages: List[ChatMessage]) -> str:
        last_user = self._last_user_message(messages)
        if not last_user:
            return "请先说“开始”开启游戏。"

        user_text = last_user.content.strip()
        normalized = user_text.lower()

        if "结束" in user_text or "游戏结束" in user_text:
            return f"游戏结束：{self.default_solution}"

        if "开始" in user_text:
            return f"{self.default_puzzle}（回答仅限“是”“否”“与此无关”）"

        return self._answer_yes_no(normalized)

    def _last_user_message(self, messages: List[ChatMessage]) -> Optional[ChatMessage]:
        for message in reversed(messages):
            if message.role == "USER":
                return message
        return None

    def _answer_yes_no(self, normalized: str) -> str:
        """
        Very small heuristic to keep answers varied but constrained.
        """
        keywords_yes = ("是", "对", "有", "发生", "曾经", "海", "船", "汤")
        keywords_irrelevant = ("谁", "什么", "几", "多少", "原因", "为什么", "why", "?")

        if any(k in normalized for k in keywords_yes):
            return "是"

        if any(k in normalized for k in keywords_irrelevant):
            return "与此无关"

        return random.choice(["否", "与此无关"])
