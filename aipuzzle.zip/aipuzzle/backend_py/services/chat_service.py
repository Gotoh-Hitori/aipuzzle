from __future__ import annotations

import threading
from typing import Dict, List

from ..config import SYSTEM_PROMPT
from ..models import ChatMessage, ChatRoom
from .ai_provider import AIProvider, RuleBasedAIProvider


class ChatService:
    def __init__(self, provider: AIProvider | None = None) -> None:
        self._provider: AIProvider = provider or RuleBasedAIProvider()
        self._histories: Dict[int, List[ChatMessage]] = {}
        self._lock = threading.Lock()

    async def do_chat(self, room_id: int, user_prompt: str) -> str:
        """
        Append the user message, ask provider, persist the assistant reply,
        and clear history if the game finishes.
        """
        with self._lock:
            messages = self._histories.setdefault(
                room_id, [ChatMessage(role="SYSTEM", content=SYSTEM_PROMPT)]
            )
            messages.append(ChatMessage(role="USER", content=user_prompt))
            history_snapshot = list(messages)

        answer = await self._provider.generate(history_snapshot)

        with self._lock:
            messages = self._histories.setdefault(
                room_id, [ChatMessage(role="SYSTEM", content=SYSTEM_PROMPT)]
            )
            messages.append(ChatMessage(role="ASSISTANT", content=answer))
            if "游戏结束" in answer:
                self._histories.pop(room_id, None)

        return answer

    def get_rooms(self) -> List[ChatRoom]:
        """
        Return current rooms with system prompts filtered out for the UI.
        """
        with self._lock:
            return [
                ChatRoom(
                    room_id=room_id,
                    chat_message=[m for m in messages if m.role != "SYSTEM"],
                )
                for room_id, messages in self._histories.items()
            ]
